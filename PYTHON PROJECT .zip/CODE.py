""""
3x2048 (powers of 3) — Visual version with clean background,
centered WIN/LOSE messages, and ribbon celebration.
"""
import pygame, random, math, sys

# --- Game constants ---
GRID_SIZE = 4
INITIAL_TILES = 2
TARGET_TILE = 6561  # 3^8
FPS = 60
WINDOW_SIZE = 600
MARGIN = 16

# --- Colors ---
BG_COLOR = (250, 248, 239)
GRID_BG = (187, 173, 160)
TEXT_COLOR_DARK = (119, 110, 101)
TEXT_COLOR_LIGHT = (249, 246, 242)
BASE_COLORS = [
    (238, 228, 218), (237, 224, 200), (242, 177, 121),
    (245, 149, 99), (246, 124, 95), (246, 94, 59),
    (237, 207, 114),
]
TILE_ROUND = 8

# --- Helper functions ---
def tile_color(val):
    if val == 0:
        return (205, 193, 180)
    k = int(round(math.log(val, 3)))
    return BASE_COLORS[min(k - 1, len(BASE_COLORS) - 1)]

def initialize_grid(size):
    return [[0] * size for _ in range(size)]

def add_new_tile(grid):
    empty = [(r, c) for r in range(GRID_SIZE) for c in range(GRID_SIZE) if grid[r][c] == 0]
    if not empty:
        return False
    r, c = random.choice(empty)
    grid[r][c] = random.choices([3, 9], weights=[9, 1], k=1)[0]
    return True

def transpose(grid): return [list(row) for row in zip(*grid)]
def reverse(grid): return [row[::-1] for row in grid]

def get_base_move(row):
    score = 0
    new_row = [t for t in row if t != 0]
    i = 0
    while i < len(new_row) - 1:
        if new_row[i] == new_row[i+1]:
            new_val = new_row[i] * 3
            score += new_val
            new_row[i] = new_val
            new_row.pop(i+1)
        i += 1
    new_row.extend([0] * (GRID_SIZE - len(new_row)))
    return new_row, score

def move_grid(grid, direction):
    total_score = 0
    working = [row[:] for row in grid]
    if direction in ('up', 'down'): working = transpose(working)
    if direction in ('right', 'down'): working = reverse(working)
    new_rows = []
    moved = False
    for row in working:
        new_row, gained = get_base_move(row)
        new_rows.append(new_row)
        total_score += gained
        if new_row != row:
            moved = True
    working = new_rows
    if direction in ('right', 'down'): working = reverse(working)
    if direction in ('up', 'down'): working = transpose(working)
    return working, total_score, moved

def check_win(grid): 
    return any(TARGET_TILE in row for row in grid)

def check_game_over(grid):
    empty_count = sum(row.count(0) for row in grid)
    if empty_count > 1:
        return False
    if empty_count == 1:
        for r in range(GRID_SIZE):
            for c in range(GRID_SIZE - 1):
                if grid[r][c] == grid[r][c+1] and grid[r][c] != 0:
                    return False
        for r in range(GRID_SIZE - 1):
            for c in range(GRID_SIZE):
                if grid[r][c] == grid[r+1][c] and grid[r][c] != 0:
                    return False
        return True
    if empty_count == 0:
        for r in range(GRID_SIZE):
            for c in range(GRID_SIZE - 1):
                if grid[r][c] == grid[r][c+1]:
                    return False
        for r in range(GRID_SIZE - 1):
            for c in range(GRID_SIZE):
                if grid[r][c] == grid[r+1][c]:
                    return False
        return True
    return False

# --- Party Ribbon particle for win celebration ---
class Ribbon:
    def __init__(self, x, y):
        self.x = x + random.uniform(-20, 20)
        self.y = y + random.uniform(-20, 20)
        self.vx = random.uniform(-4, 4)
        self.vy = random.uniform(-6, -1)
        self.w = random.uniform(6, 18)
        self.h = random.uniform(18, 48)
        self.angle = random.uniform(0, 360)
        self.ang_vel = random.uniform(-6, 6)
        self.life = random.uniform(80, 160)
        self.color = random.choice([
            (255, 50, 90), (255, 170, 60), (100, 220, 180), (140, 100, 255),
            (255, 105, 180), (255, 215, 70)
        ])
        self.alpha = 255
    def update(self):
        self.vy += 0.18
        self.vx *= 0.998
        self.x += self.vx
        self.y += self.vy
        self.angle += self.ang_vel
        self.life -= 1
        self.alpha = max(0, int(255 * (self.life / 160)))
        return self.life > 0 and self.y < WINDOW_SIZE + 100
    def draw(self, surface):
        surf = pygame.Surface((int(self.w*2), int(self.h*2)), pygame.SRCALPHA)
        rect = pygame.Rect(int(self.w//2), int(self.h//2), int(self.w), int(self.h))
        pygame.draw.rect(surf, (*self.color, self.alpha), rect, border_radius=3)
        rotated = pygame.transform.rotate(surf, self.angle)
        rx = int(self.x - rotated.get_width() / 2)
        ry = int(self.y - rotated.get_height() / 2)
        surface.blit(rotated, (rx, ry))

# --- Drawing helpers ---
def draw_rounded_rect(surface, rect, color, radius): 
    pygame.draw.rect(surface, color, rect, border_radius=radius)
def value_to_textsurf(val):
    if val == 0: return None
    color = TEXT_COLOR_DARK if val <= 81 else TEXT_COLOR_LIGHT
    size = 48 if len(str(val))<=2 else (32 if len(str(val))==3 else 24)
    f = pygame.font.SysFont(None, size, bold=True)
    return f.render(str(val), True, color)

# --- Game container ---
class Game:
    def __init__(self):
        self.reset()
    def reset(self):
        self.board = initialize_grid(GRID_SIZE)
        for _ in range(INITIAL_TILES): add_new_tile(self.board)
        self.score = 0
        self.win = False
        self.game_over = False
        self.win_timer = 0
    def request_move(self, direction):
        if self.game_over or self.win: return
        new_board, gained, moved = move_grid(self.board, direction)
        if not moved: return
        self.board = new_board
        self.score += gained
        add_new_tile(self.board)
        if check_win(self.board):
            self.win = True
            self.win_timer = 0
        elif check_game_over(self.board):
            self.game_over = True

# --- Main ---
def main():
    pygame.init()
    screen = pygame.display.set_mode((WINDOW_SIZE, WINDOW_SIZE))
    pygame.display.set_caption("6561🎀")
    clock = pygame.time.Clock()
    game = Game()
    base_font = pygame.font.SysFont(None, 28, bold=True)
    big_font = pygame.font.SysFont(None, 56, bold=True)
    small_font = pygame.font.SysFont(None, 20)
    ribbons = []

    def draw_board():
        screen.fill(BG_COLOR)
        grid_size_px = WINDOW_SIZE - 2*MARGIN
        grid_rect = pygame.Rect(MARGIN, 80, grid_size_px, grid_size_px-60)
        draw_rounded_rect(screen, grid_rect, GRID_BG, 10)
        cell_w = grid_rect.width / GRID_SIZE
        cell_h = grid_rect.height / GRID_SIZE
        for r in range(GRID_SIZE):
            for c in range(GRID_SIZE):
                val = game.board[r][c]
                x = grid_rect.left + c*cell_w + 8
                y = grid_rect.top + r*cell_h + 8
                rect = pygame.Rect(x, y, cell_w-16, cell_h-16)
                draw_rounded_rect(screen, rect, tile_color(val), TILE_ROUND)
                surf = value_to_textsurf(val)
                if surf:
                    screen.blit(surf, surf.get_rect(center=rect.center))
        score_surf = base_font.render(f"Score: {game.score}", True, (80,70,60))
        screen.blit(score_surf, (MARGIN, 30))
        return grid_rect

    running = True
    while running:
        dt = clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_q, pygame.K_ESCAPE):
                    running = False
                elif event.key == pygame.K_n:
                    game.reset()
                    ribbons.clear()
                elif not game.win and not game.game_over:
                    if event.key in (pygame.K_w, pygame.K_UP): game.request_move("up")
                    elif event.key in (pygame.K_s, pygame.K_DOWN): game.request_move("down")
                    elif event.key in (pygame.K_a, pygame.K_LEFT): game.request_move("left")
                    elif event.key in (pygame.K_d, pygame.K_RIGHT): game.request_move("right")

        if game.win:
            game.win_timer += 1
            burst_rate = 20 if game.win_timer < 18 else 3
            if random.random() < burst_rate/60.0 and len(ribbons) < 300:
                for _ in range(random.randint(2,5)):
                    center_x = MARGIN + (WINDOW_SIZE - 2*MARGIN) / 2
                    center_y = 80 + (WINDOW_SIZE - 2*MARGIN - 60) / 2
                    ribbons.append(Ribbon(center_x, center_y))

        ribbons[:] = [r for r in ribbons if r.update()]
        grid_rect = draw_board()
        for r in ribbons:
            r.draw(screen)

        if game.win:
            pop = 1.0 + 0.06 * math.sin(pygame.time.get_ticks() * 0.006)
            font = pygame.font.SysFont(None, int(64 * pop), bold=True)
            msg = "YOU WON!"
            text = font.render(msg, True, (255, 50, 120))
            shadow = font.render(msg, True, (0,0,0,80))
            tx = grid_rect.centerx - text.get_width()/2
            ty = grid_rect.centery - text.get_height()/2 - 10
            screen.blit(shadow, (tx+4, ty+4))
            screen.blit(text, (tx, ty))
            sub = small_font.render("Press N to restart", True, (80, 40, 100))
            screen.blit(sub, sub.get_rect(center=(grid_rect.centerx, grid_rect.centery + 40)))

        if game.game_over:
            overlay = pygame.Surface((int(grid_rect.width), int(grid_rect.height)), pygame.SRCALPHA)
            overlay.fill((0,0,0,120))
            screen.blit(overlay, (grid_rect.left, grid_rect.top))
            font = pygame.font.SysFont(None, 52, bold=True)
            msg = "YOU LOST"
            text = font.render(msg, True, (255, 255, 255))
            tx = grid_rect.centerx - text.get_width()/2
            ty = grid_rect.centery - text.get_height()/2 - 8
            screen.blit(text, (tx, ty))
            sub = small_font.render("Press N to try again", True, (220,220,220))
            screen.blit(sub, sub.get_rect(center=(grid_rect.centerx, grid_rect.centery + 36)))

        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()